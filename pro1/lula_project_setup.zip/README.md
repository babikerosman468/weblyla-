# Lula Project DB Automation

## Contents

- **lula_schema.sql** – Full database schema and starter data.
- **deploy_lula.sh** – Bash script to deploy manually.
- **docker-compose.yml** – Spin up MariaDB in Docker with Lula DB auto-loaded.

## Usage

### 🗂️ 1. Local Manual Deployment

Edit `deploy_lula.sh` with your DB password:

```bash
DB_PASS="your_password_here"
```

Run:
```bash
chmod +x deploy_lula.sh
./deploy_lula.sh
```

### 🐳 2. Docker Deployment

Edit `docker-compose.yml` and replace `MYSQL_ROOT_PASSWORD`.

Run:
```bash
docker-compose up
```

MariaDB will spin up on port 3306 with `lula_schema.sql` loaded.

## Connect to DB

```bash
mysql -u root -p
USE lula;
SHOW TABLES;
```

✅ Enjoy your Lula Project!
