#!/bin/bash

DB_NAME="lula"
DB_USER="root"
DB_PASS="your_password_here"

echo "🚀 Starting Lula DB deployment..."

mysql -u $DB_USER -p$DB_PASS $DB_NAME < lula_schema.sql

echo "✅ Lula DB deployed successfully!"
